sudo lsmod | grep br_netfilter
sudo modprobe br_netfilter
sudo touch /etc/sysctl.d/k8s.conf
sudo chown mario:mario /etc/sysctl.d/k8s.conf
sudo cat <<EOF >  /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF
sudo sysctl --system

sudo hostnamectl set-hostname master

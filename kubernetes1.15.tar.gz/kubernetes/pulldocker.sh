sudo docker pull mariolz/kuberneters1.15:apiserver
sudo docker pull mariolz/kuberneters1.15:controller-manager
sudo docker pull mariolz/kuberneters1.15:coredns
sudo docker pull mariolz/kuberneters1.15:etcd
sudo docker pull mariolz/kuberneters1.15:pause
sudo docker pull mariolz/kuberneters1.15:proxy
sudo docker pull mariolz/kuberneters1.15:scheduler
sudo docker tag  mariolz/kuberneters1.15:apiserver k8s.gcr.io/kube-apiserver:v1.15.3 
sudo docker tag  mariolz/kuberneters1.15:controller-manager k8s.gcr.io/kube-controller-manager:v1.15.3
sudo docker tag  mariolz/kuberneters1.15:scheduler k8s.gcr.io/kube-scheduler:v1.15.3
sudo docker tag  mariolz/kuberneters1.15:proxy k8s.gcr.io/kube-proxy:v1.15.3
sudo docker tag  mariolz/kuberneters1.15:pause k8s.gcr.io/pause:3.1
sudo docker tag  mariolz/kuberneters1.15:etcd k8s.gcr.io/etcd:3.3.10
sudo docker tag  mariolz/kuberneters1.15:coredns   k8s.gcr.io/coredns:1.3.1
sudo docker rmi mariolz/kuberneters1.15:apiserver
sudo docker rmi  mariolz/kuberneters1.15:controller-manager
sudo docker rmi mariolz/kuberneters1.15:coredns
sudo docker rmi mariolz/kuberneters1.15:etcd
sudo docker rmi mariolz/kuberneters1.15:pause
sudo docker rmi mariolz/kuberneters1.15:proxy
sudo docker rmi mariolz/kuberneters1.15:scheduler

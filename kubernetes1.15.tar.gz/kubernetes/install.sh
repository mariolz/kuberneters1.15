#kuberneters1.15.3  master installer script
#!/usr/bin/bash
./sethostname.sh
./setiptables.sh
./ipvs.sh
./pulldocker.sh
./install_kubeadm.sh
./init.sh

